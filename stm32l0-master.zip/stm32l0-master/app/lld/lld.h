#ifndef LLD_H
#define LLD_H

#include <stdlib.h>
#include <string.h>

#include "stm32l053xx.h"
#include "various.h"
#include "rcc.h"
#include "gpio.h"
#include "spi.h"
#include "i2c.h"
#include "usart.h"

#endif
#ifndef GDE021A1_H
#define GDE021A1_H

#include "lld.h"

void gde021a1Init();

void gde021a1Test();

#endif
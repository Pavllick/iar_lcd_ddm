
openocd -f board/stm32l0discovery.cfg
